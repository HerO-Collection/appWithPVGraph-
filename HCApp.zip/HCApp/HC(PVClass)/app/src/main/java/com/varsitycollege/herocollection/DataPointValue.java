package com.varsitycollege.herocollection;

public class DataPointValue {
    int mValue,zValue;

    public DataPointValue(){}

    public DataPointValue(int mValue, int zValue) {
        this.mValue = mValue;
        this.zValue = zValue;
    }

    public int getmValue() {
        return mValue;
    }


    public int getzValue() {
        return zValue;
    }


}
