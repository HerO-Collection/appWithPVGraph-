package com.varsitycollege.herocollection;

public class PICK_IMAGE_REQUEST {
}
