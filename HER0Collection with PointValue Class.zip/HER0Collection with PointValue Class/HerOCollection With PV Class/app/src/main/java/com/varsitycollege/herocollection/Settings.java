package com.varsitycollege.herocollection;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Settings extends AppCompatActivity
{
        private ImageButton settings;
        private Button logoutOfSettings;

        @Override
        protected void onCreate(Bundle savedInstanceState)
        {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_settings);

            ActionBar actionBar = getSupportActionBar();

            actionBar.setDisplayHomeAsUpEnabled(true);

            //settings = findViewById(R.id.settingsButtonMenus);
            logoutOfSettings = findViewById(R.id.logout_settings);

            logoutOfSettings.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {
                    Intent i = new Intent(Settings.this, LogOut.class);

                    startActivity(i);
                }
            });

        /*settings.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent i = new Intent(Settings.this, LogOut.class);

                startActivity(i);
            }
        });*/
        }

        public boolean onOptionsItemSelected(@NonNull MenuItem item)
        {

            switch (item.getItemId())
            {
                case android.R.id.home:
                    this.finish();
                    return true;

            }
            return super.onOptionsItemSelected(item);
        }
}